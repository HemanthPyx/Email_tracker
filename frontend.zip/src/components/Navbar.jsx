/**
 * Navigation bar component.
 */
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { HiOutlineViewGrid, HiOutlineSearch, HiOutlineMail, HiOutlineClock, HiOutlineLogout } from 'react-icons/hi';

const navItems = [
  { to: '/', label: 'Dashboard', icon: HiOutlineViewGrid },
  { to: '/search', label: 'Search', icon: HiOutlineSearch },
  { to: '/accounts', label: 'Accounts', icon: HiOutlineMail },
  { to: '/scans', label: 'Scan History', icon: HiOutlineClock },
];

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="sticky top-0 z-50 bg-dark-surface/80 backdrop-blur-xl border-b border-dark-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-brand-blue/20 flex items-center justify-center">
              <HiOutlineMail className="w-5 h-5 text-brand-blue" />
            </div>
            <span className="text-lg font-bold text-text-primary tracking-tight">
              Mail<span className="text-brand-blue">Tracker</span>
            </span>
          </div>

          {/* Nav Links */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-brand-blue/15 text-brand-blue'
                      : 'text-text-secondary hover:text-text-primary hover:bg-dark-hover'
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                {label}
              </NavLink>
            ))}
          </div>

          {/* User menu */}
          <div className="flex items-center gap-3">
            {user?.avatar_url ? (
              <img
                src={user.avatar_url}
                alt={user.first_name}
                className="w-8 h-8 rounded-full border-2 border-dark-border"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-brand-blue/20 flex items-center justify-center">
                <span className="text-sm font-semibold text-brand-blue">
                  {user?.first_name?.[0] || user?.email?.[0] || '?'}
                </span>
              </div>
            )}
            <button
              onClick={handleLogout}
              className="btn-ghost !p-2 text-text-muted hover:text-brand-red"
              title="Logout"
            >
              <HiOutlineLogout className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile nav */}
        <div className="md:hidden flex items-center gap-1 pb-3 overflow-x-auto">
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all duration-200 ${
                  isActive
                    ? 'bg-brand-blue/15 text-brand-blue'
                    : 'text-text-secondary hover:text-text-primary'
                }`
              }
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </NavLink>
          ))}
        </div>
      </div>
    </nav>
  );
}
